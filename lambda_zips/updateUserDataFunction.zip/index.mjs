import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const USER_DATA_TABLE = process.env.USER_DATA_TABLE;

export const handler = async (event) => {
  try {
    // --- 日志 ---
    console.log("--- updateUserDataFunction Invoked ---");
    console.log("Received event:", JSON.stringify(event, null, 2));

    const userEmail = event.requestContext.authorizer.email;
    // --- 日志 ---
    console.log("User Email from Authorizer:", userEmail);

    if (!userEmail) {
      throw new Error("User email not found in authorizer context.");
    }

    const { themes, records } = JSON.parse(event.body);
    // --- 日志 ---
    console.log("Received themes from frontend:", JSON.stringify(themes, null, 2));
    console.log("Received records from frontend:", JSON.stringify(records, null, 2));

    const itemToSave = {
      email: userEmail,
      themes: themes,
      records: records,
      updated_at: new Date().toISOString(),
    };

    // --- 日志 ---
    console.log("Item being sent to DynamoDB:", JSON.stringify(itemToSave, null, 2));
    
    const putCommand = new PutCommand({
      TableName: USER_DATA_TABLE,
      Item: itemToSave,
    });

    await docClient.send(putCommand);
    
    // --- 日志 ---
    console.log("DynamoDB PutCommand successful!");

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "数据更新成功" }),
    };

  } catch (error) {
    // --- 日志 ---
    console.error("!!! AN ERROR OCCURRED !!!", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "更新数据时发生内部错误" }),
    };
  }
};
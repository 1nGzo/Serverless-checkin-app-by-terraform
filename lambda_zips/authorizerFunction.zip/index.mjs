import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET;

const generatePolicy = (principalId, effect, resource, context = {}) => {
  return {
    principalId,
    policyDocument: {
      Version: "2012-10-17",
      Statement: [
        {
          Action: "execute-api:Invoke",
          Effect: effect,
          Resource: resource,
        },
      ],
    },
    context,
  };
};

export const handler = async (event) => {
  console.log("--- authorizerFunction Invoked ---");
  console.log("Received event:", JSON.stringify(event, null, 2));

  try {
    const authHeader = event.authorizationToken;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      console.error("Missing or invalid authorizationToken");
      return generatePolicy("unauthorized", "Deny", event.methodArn);
    }

    const token = authHeader.replace("Bearer ", "");
    const decoded = jwt.verify(token, JWT_SECRET);

    console.log("Token verified for:", decoded.email);

    return generatePolicy(
      decoded.email,
      "Allow",
      event.methodArn,
      {
        email: decoded.email,
      }
    );

  } catch (error) {
    console.error("Token 验证失败:", error);
    return generatePolicy("unauthorized", "Deny", event.methodArn);
  }
};
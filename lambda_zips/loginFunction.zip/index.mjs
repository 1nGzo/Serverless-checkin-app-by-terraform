import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand } from "@aws-sdk/lib-dynamodb";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const USERS_TABLE = "users";
const JWT_SECRET = process.env.JWT_SECRET; // 从环境变量获取密钥

export const handler = async (event) => {
  const { email, password } = JSON.parse(event.body);

  if (!email || !password) {
    return { statusCode: 400, body: JSON.stringify({ message: "Email 和密码不能为空" }) };
  }

  try {
    const getCommand = new GetCommand({
      TableName: USERS_TABLE,
      Key: { email: email },
    });
    const { Item } = await docClient.send(getCommand);

    if (!Item) {
      return { statusCode: 401, body: JSON.stringify({ message: "用户不存在或密码错误" }) };
    }

    const isPasswordCorrect = await bcrypt.compare(password, Item.password_hash);

    if (!isPasswordCorrect) {
      return { statusCode: 401, body: JSON.stringify({ message: "用户不存在或密码错误" }) };
    }

    // 密码正确，签发 JWT
    const token = jwt.sign(
      { email: Item.email }, // Payload - 荷载
      JWT_SECRET,             // Secret - 密钥
      { expiresIn: '8h' }    // Options - 选项，例如8小时后过期
    );

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "登录成功", token: token }),
    };
  } catch (error) {
    console.error("登录错误:", error);
    return { statusCode: 500, body: JSON.stringify({ message: "服务器内部错误" }) };
  }
};

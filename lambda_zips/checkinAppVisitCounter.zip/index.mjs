import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, UpdateCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
    const tableName = process.env.DYNAMODB_TABLE_NAME;
    if (!tableName) {
        throw new Error("DYNAMODB_TABLE_NAME environment variable is not set.");
    }

    const today = new Date().toISOString().slice(0, 10);

    try {
        /** 第一步：确保 DailyVisits 存在 **/
        const ensureCommand = new UpdateCommand({
            TableName: tableName,
            Key: { StatID: "SiteVisitCounter" },
            UpdateExpression: "SET DailyVisits = if_not_exists(DailyVisits, :empty_map)",
            ExpressionAttributeValues: {
                ":empty_map": {}
            }
        });
        await docClient.send(ensureCommand);

        /** 第二步：递增 TotalVisits 和 DailyVisits[today] **/
        const incrementCommand = new UpdateCommand({
            TableName: tableName,
            Key: { StatID: "SiteVisitCounter" },
            UpdateExpression:
                "SET LastUpdated = :now, " +
                "TotalVisits = if_not_exists(TotalVisits, :zero) + :one, " +
                "DailyVisits.#today = if_not_exists(DailyVisits.#today, :zero) + :one",
            ExpressionAttributeNames: {
                "#today": today
            },
            ExpressionAttributeValues: {
                ":zero": 0,
                ":one": 1,
                ":now": new Date().toISOString()
            },
            ReturnValues: "ALL_NEW"
        });

        const response = await docClient.send(incrementCommand);

        /** 返回最新统计数据 **/
        const item = response.Attributes || {};
        const total = item.TotalVisits ?? 0;
        const todayCount = item.DailyVisits?.[today] ?? 0;

        return {
            statusCode: 200,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify({
                total,
                today: todayCount
            })
        };
    } catch (error) {
        console.error("DynamoDB update failed:", error);
        return {
            statusCode: 500,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify({ message: "Internal server error" })
        };
    }
};

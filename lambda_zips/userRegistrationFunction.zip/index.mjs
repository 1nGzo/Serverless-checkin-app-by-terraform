import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";
import bcrypt from "bcryptjs"; // 提示: 您需要将此依赖打包上传

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const USERS_TABLE = "users"; // 您的DynamoDB表名

export const handler = async (event) => {
  // API Gateway 会将请求体作为字符串传递
  const { email, password } = JSON.parse(event.body);

  if (!email || !password) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: "Email 和密码不能为空" }),
    };
  }

  const salt = await bcrypt.genSalt(10);
  const password_hash = await bcrypt.hash(password, salt);

  const command = new PutCommand({
    TableName: USERS_TABLE,
    Item: {
      email: email,
      password_hash: password_hash,
      created_at: new Date().toISOString(),
    },
    // 添加条件表达式，如果email已存在，则操作失败
    ConditionExpression: "attribute_not_exists(email)",
  });

  try {
    await docClient.send(command);
    return {
      statusCode: 201,
      body: JSON.stringify({ message: "用户注册成功" }),
    };
  } catch (error) {
    if (error.name === "ConditionalCheckFailedException") {
      return {
        statusCode: 409,
        body: JSON.stringify({ message: "此 Email 已被注册" }),
      };
    }
    console.error("数据库错误:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "服务器内部错误" }),
    };
  }
};

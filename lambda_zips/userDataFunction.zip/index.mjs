import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const USER_DATA_TABLE = process.env.USER_DATA_TABLE;

export const handler = async (event) => {
  try {
    // --- 日誌 ---
    console.log("--- userDataFunction Invoked ---");
    console.log("Received event:", JSON.stringify(event, null, 2));

    const userEmail = event.requestContext.authorizer.email;
    // --- 日誌 ---
    console.log("User Email from Authorizer:", userEmail);

    if (!userEmail) {
      throw new Error("User email not found in authorizer context.");
    }

    const getCommand = new GetCommand({
      TableName: USER_DATA_TABLE,
      Key: {
        email: userEmail,
      },
    });

    // --- 日誌 ---
    console.log("Attempting to get item from DynamoDB with key:", userEmail);

    const { Item } = await docClient.send(getCommand);

    // --- 日誌 ---
    console.log("DynamoDB response (Item):", JSON.stringify(Item, null, 2));

    if (!Item) {
      console.log("No item found for this user. Returning default empty structure.");
      return {
        statusCode: 200,
        body: JSON.stringify({ email: userEmail, themes: [], records: {} }),
      };
    }

    console.log("Item found. Returning data to frontend.");
    return {
      statusCode: 200,
      body: JSON.stringify({
        email: Item.email,
        themes: Item.themes || [],
        records: Item.records || {},
      }),
    };

  } catch (error) {
    // --- 日誌 ---
    console.error("!!! AN ERROR OCCURRED in userDataFunction !!!", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "獲取用戶數據時發生內部錯誤" }),
    };
  }
};